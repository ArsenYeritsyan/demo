package com.example.demo.persistance.model;

public enum MovieGenre {
    COMEDY,
    ACTION,
    CRIME,
    HORROR
}
